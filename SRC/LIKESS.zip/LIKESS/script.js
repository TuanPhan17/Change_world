function change(button){
    button.previousElementSibling.innerHTML++;
}