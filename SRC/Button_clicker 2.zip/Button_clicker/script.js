console.log("script.js")


// function change(button){
//    button.innerText="Logout"
// }